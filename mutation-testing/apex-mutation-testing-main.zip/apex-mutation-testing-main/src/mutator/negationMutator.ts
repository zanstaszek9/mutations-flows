import { ParserRuleContext } from 'antlr4ts'
import { TerminalNode } from 'antlr4ts/tree/index.js'
import { TypeRegistry } from '../type/TypeRegistry.js'
import { BaseListener } from './baseListener.js'

export class NegationMutator extends BaseListener {
  private static readonly ZERO_LITERAL = /^0+(\.0+)?[lLdD]?$/

  constructor(typeRegistry?: TypeRegistry) {
    super(typeRegistry)
  }

  enterReturnStatement(ctx: ParserRuleContext): void {
    if (!this.isNumericReturn(ctx)) {
      return
    }

    // The length half is unreachable: a return statement always has at least
    // the `return` keyword plus its terminator.
    // Stryker disable next-line ConditionalExpression: unreachable.
    if (!ctx.children || ctx.children.length < 2) {
      return
    }

    const expressionNode = ctx.children[1]
    // Unreachable via the parser: a bare `return;` only occurs in a void
    // method, so child 1 is always the returned expression here.
    // Stryker disable next-line ConditionalExpression,BlockStatement: unreachable.
    if (!(expressionNode instanceof ParserRuleContext)) {
      return
    }

    if (this.isNegatedExpression(expressionNode)) {
      return
    }

    const expressionText = expressionNode.text
    if (NegationMutator.ZERO_LITERAL.test(expressionText)) {
      return
    }

    const replacement = this.formatNegation(expressionText, expressionNode)

    this.createMutationFromParserRuleContext(expressionNode, replacement)
  }

  private isNumericReturn(ctx: ParserRuleContext): boolean {
    if (!this.typeRegistry) return false
    const methodName = this.getEnclosingMethodName(ctx)
    return !!methodName && this.typeRegistry.isNumericReturn(methodName)
  }

  private isNegatedExpression(expr: ParserRuleContext): boolean {
    if (expr.childCount !== 2) {
      return false
    }

    const firstChild = expr.getChild(0)
    if (!(firstChild instanceof TerminalNode)) {
      return false
    }

    return firstChild.text === '-'
  }

  private formatNegation(
    expressionText: string,
    expressionNode: ParserRuleContext
  ): string {
    const isComplexExpression = expressionNode.childCount > 1

    if (isComplexExpression) {
      return `-(${expressionText})`
    }

    return `-${expressionText}`
  }
}
