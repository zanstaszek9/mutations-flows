import { ParserRuleContext, Token } from 'antlr4ts'
import { TerminalNode } from 'antlr4ts/tree/index.js'
import { ApexParserListener, ReturnStatementContext } from 'apex-parser'
import { ApexMutation } from '../type/ApexMutation.js'
import { TypeRegistry } from '../type/TypeRegistry.js'
import { getEnclosingMethodName } from './astUtils.js'

// @ts-ignore: Base type with just a common _mutations property
export class BaseListener implements ApexParserListener {
  _mutations: ApexMutation[] = []
  _coveredLines?: Set<number>

  setCoveredLines(coveredLines: Set<number>): void {
    this._coveredLines = coveredLines
  }

  constructor(protected typeRegistry?: TypeRegistry) {}

  protected getEnclosingMethodName(ctx: ParserRuleContext): string | null {
    return getEnclosingMethodName(ctx)
  }

  protected isInsideReturnStatement(ctx: ParserRuleContext): boolean {
    let current: ParserRuleContext | undefined = ctx.parent as
      | ParserRuleContext
      | undefined
    while (current) {
      if (current instanceof ReturnStatementContext) {
        return true
      }
      current = current.parent as ParserRuleContext | undefined
    }
    return false
  }

  protected createMutation(
    startToken: Token,
    endToken: Token,
    originalText: string,
    replacement: string
  ): void {
    this._mutations.push({
      mutationName: this.constructor.name,
      target: {
        startToken,
        endToken,
        text: originalText,
      },
      replacement,
    })
  }

  protected createMutationFromParserRuleContext(
    ctx: ParserRuleContext,
    replacement: string
  ): void {
    if (ctx.start && ctx.stop) {
      this.createMutation(ctx.start, ctx.stop, ctx.text, replacement)
    }
  }

  protected createMutationFromTerminalNode(
    node: TerminalNode,
    replacement: string
  ): void {
    if (node.symbol) {
      this.createMutation(node.symbol, node.symbol, node.text, replacement)
    }
  }

  protected isNonNumericContext(ctx: ParserRuleContext): boolean {
    const leftText = ctx.getChild(0).text
    const rightText = ctx.getChild(2).text
    if (leftText.includes("'") || rightText.includes("'")) return true
    if (!this.typeRegistry) return false
    const methodName = this.getEnclosingMethodName(ctx)
    // Not observable: an expression always sits inside a method, and even
    // without one `isNumericOperand(undefined, ...)` misses the scope table and
    // reports non-numeric, which the caller treats the same as this early exit.
    // Stryker disable next-line ConditionalExpression: same result either way.
    if (!methodName) return false
    return (
      !this.typeRegistry.isNumericOperand(methodName, leftText) ||
      !this.typeRegistry.isNumericOperand(methodName, rightText)
    )
  }
}
