import {
  formatDuration,
  formatRemainingTime,
  timeExecution,
} from '../../../src/service/timeUtils.js'

describe('timeUtils', () => {
  describe('timeExecution', () => {
    describe('Given an async function that resolves', () => {
      describe('When timing its execution', () => {
        it('Then it returns the function result and a positive duration', async () => {
          // Arrange
          const expected = 'test-result'
          const fn = async () => expected

          // Act
          const sut = await timeExecution(fn)

          // Assert
          expect(sut.result).toBe(expected)
          expect(sut.durationMs).toBeGreaterThanOrEqual(0)
        })
      })
    })

    describe('Given an async function that rejects', () => {
      describe('When timing its execution', () => {
        it('Then it propagates the error', async () => {
          // Arrange
          const error = new Error('test-error')
          const fn = async () => {
            throw error
          }

          // Act & Assert
          await expect(timeExecution(fn)).rejects.toThrow('test-error')
        })
      })
    })

    describe('Given an async function with measurable delay', () => {
      describe('When timing its execution', () => {
        it('Then the duration reflects the elapsed time', async () => {
          // Arrange — fake performance so duration is deterministic.
          // Use a counter-driven stub so adding a third internal call
          // (e.g. wrapping timeExecution in retry logic) cannot silently
          // leak the real performance.now() and produce flaky numbers.
          const delayMs = 50
          const times = [1000, 1000 + delayMs]
          let idx = 0
          const performanceSpy = vi
            .spyOn(performance, 'now')
            .mockImplementation(() => {
              if (idx >= times.length) {
                throw new Error(
                  `timeExecution made ${idx + 1} performance.now() calls; fixture expects ${times.length}`
                )
              }
              return times[idx++]
            })
          const fn = async () => 'delayed'

          // Act
          const sut = await timeExecution(fn)

          // Assert
          expect(sut.result).toBe('delayed')
          expect(sut.durationMs).toBe(delayMs)
          expect(idx).toBe(2) // exactly start + end reads
          performanceSpy.mockRestore()
        })
      })
    })
  })

  describe('formatDuration', () => {
    describe('Given milliseconds less than 60 seconds', () => {
      describe('When formatting duration', () => {
        it('Then it returns seconds only for 0ms', () => {
          // Act
          const sut = formatDuration(0)

          // Assert
          expect(sut).toBe('~0s')
        })

        it('Then it returns seconds only for sub-second values', () => {
          // Act
          const sut = formatDuration(500)

          // Assert
          expect(sut).toBe('~0s')
        })

        it('Then it returns seconds only for exact seconds', () => {
          // Act
          const sut = formatDuration(45_000)

          // Assert
          expect(sut).toBe('~45s')
        })

        it('Then it truncates fractional seconds', () => {
          // Act
          const sut = formatDuration(59_999)

          // Assert
          expect(sut).toBe('~59s')
        })
      })
    })

    describe('Given milliseconds in the minutes range', () => {
      describe('When formatting duration', () => {
        it('Then it returns minutes and seconds for exactly 60s', () => {
          // Act
          const sut = formatDuration(60_000)

          // Assert
          expect(sut).toBe('~1m 0s')
        })

        it('Then it returns minutes and seconds', () => {
          // Act
          const sut = formatDuration(750_000)

          // Assert
          expect(sut).toBe('~12m 30s')
        })

        it('Then it returns minutes and seconds at upper boundary', () => {
          // Act
          const sut = formatDuration(3_599_999)

          // Assert
          expect(sut).toBe('~59m 59s')
        })
      })
    })

    describe('Given milliseconds in the hours range', () => {
      describe('When formatting duration', () => {
        it('Then it returns hours, minutes, and seconds for exactly 1 hour', () => {
          // Act
          const sut = formatDuration(3_600_000)

          // Assert
          expect(sut).toBe('~1h 0m 0s')
        })

        it('Then it returns hours, minutes, and seconds', () => {
          // Act
          const sut = formatDuration(3_661_000)

          // Assert
          expect(sut).toBe('~1h 1m 1s')
        })

        it('Then it returns multi-hour durations', () => {
          // Act
          const sut = formatDuration(7_265_000)

          // Assert
          expect(sut).toBe('~2h 1m 5s')
        })
      })
    })
  })

  describe('formatRemainingTime', () => {
    it('given completedCount is 0 when called then returns empty string', () => {
      // Arrange
      const loopStartTime = performance.now()

      // Act
      const result = formatRemainingTime(loopStartTime, 0, 10)

      // Assert — must be exactly '' (kills the StringLiteral and EqualityOperator mutants)
      expect(result).toBe('')
      expect(result).not.toContain('|')
    })

    it('given completedCount > 0 when called then returns string ending with " | "', () => {
      // Arrange
      const loopStartTime = 1000
      const fakeNow = vi.spyOn(performance, 'now')
      fakeNow.mockReturnValue(loopStartTime + 500)

      // Act
      const result = formatRemainingTime(loopStartTime, 1, 5)

      // Assert
      expect(result).toMatch(/\| $/)
      expect(result).toContain('Remaining:')
      fakeNow.mockRestore()
    })

    it('given completedCount=2 of 10 with 60s elapsed when called then remaining time is proportional', () => {
      // Arrange — fixtures chosen so every arithmetic mutant formats to a
      // DISTINCT duration, making the exact-equality assert below sufficient:
      //   correct        (60000/2)*(10-2) = 240000ms -> ~4m 0s
      //   elapsed - → +  (80000/2)*(10-2) = 320000ms -> ~5m 20s
      //   / → *          (60000*2)*(10-2) = 960000ms -> ~16m 0s
      //   count  - → +   (60000/2)*(10+2) = 360000ms -> ~6m 0s
      const loopStartTime = 10_000
      const fakeNow = vi.spyOn(performance, 'now')
      fakeNow.mockReturnValue(loopStartTime + 60_000)

      // Act
      const result = formatRemainingTime(loopStartTime, 2, 10)

      // Assert
      expect(result).toBe('Remaining: ~4m 0s | ')
      fakeNow.mockRestore()
    })

    it('given completedCount equals totalCount when called then formatDuration receives 0', () => {
      // Arrange — completed == total means zero work left, whatever the elapsed.
      const loopStartTime = 5000
      const fakeNow = vi.spyOn(performance, 'now')
      fakeNow.mockReturnValue(loopStartTime + 200)

      // Act
      const result = formatRemainingTime(loopStartTime, 10, 10)

      // Assert — remaining = (200/10) * (10-10) = 0 → formatted as '~0s'
      expect(result).toBe('Remaining: ~0s | ')
      fakeNow.mockRestore()
    })
  })
})
