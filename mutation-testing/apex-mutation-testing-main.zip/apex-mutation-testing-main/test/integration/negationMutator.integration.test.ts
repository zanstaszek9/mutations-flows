import {
  ApexLexer,
  ApexParser,
  ApexParserListener,
  CaseInsensitiveInputStream,
  CommonTokenStream,
  ParseTreeWalker,
} from 'apex-parser'
import { MutationListener } from '../../src/mutator/mutationListener.js'
import { NegationMutator } from '../../src/mutator/negationMutator.js'
import { TypeDiscoverer } from '../../src/service/typeDiscoverer.js'
import { AliasTypeMatcher } from '../../src/service/typeMatcher.js'

describe('NegationMutator Integration', () => {
  const parseAndMutate = async (code: string, coveredLines: Set<number>) => {
    const lexer = new ApexLexer(new CaseInsensitiveInputStream('test', code))
    const tokenStream = new CommonTokenStream(lexer)
    const parser = new ApexParser(tokenStream)
    const tree = parser.compilationUnit()

    const typeDiscoverer = new TypeDiscoverer()
      .withMatcher(new AliasTypeMatcher([]))
      .withMatcher(new AliasTypeMatcher([]))
    const typeRegistry = await typeDiscoverer.analyze(code)

    const negationMutator = new NegationMutator(typeRegistry)
    const listener = new MutationListener([negationMutator], coveredLines)

    ParseTreeWalker.DEFAULT.walk(listener as ApexParserListener, tree)
    return listener.getMutations()
  }

  describe('Given Apex code with return statement returning variable', () => {
    it('Then should generate mutation to negate the variable', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test() {
            return x;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-x')
      expect(mutations[0].mutationName).toBe('NegationMutator')
    })
  })

  describe('Given Apex code with return statement returning numeric literal', () => {
    it('Then should generate mutation to negate the literal', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test() {
            return 42;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-42')
    })
  })

  describe('Given Apex code with return statement already negated', () => {
    it('Then should not generate mutation', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test() {
            return -x;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with multiple return statements', () => {
    it('Then should generate mutations for each eligible return', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test(Boolean condition) {
            if (condition) {
              return x;
            }
            return y;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([5, 7]))

      // Assert
      expect(mutations.length).toBe(2)
      expect(mutations[0].replacement).toBe('-x')
      expect(mutations[1].replacement).toBe('-y')
    })
  })

  describe('Given Apex code with return statement returning boolean', () => {
    it('Then should not generate mutation for Boolean return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Boolean test() {
            return true;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })

    it('Then should not generate mutation for false', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Boolean test() {
            return false;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with return statement returning null', () => {
    it('Then should not generate mutation for Object return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Object test() {
            return null;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with return statement returning string', () => {
    it('Then should not generate mutation for String return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public String test() {
            return 'hello';
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with void return', () => {
    it('Then should not generate mutation', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public void test() {
            return;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with return on uncovered lines', () => {
    it('Then should not generate mutations', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test() {
            return x;
          }
        }
      `

      // Act - line 4 is not covered
      const mutations = await parseAndMutate(code, new Set([5]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })

  describe('Given Apex code with return statement returning expression', () => {
    it('Then should generate mutation with parentheses around the expression', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Integer test() {
            return a + b;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-(a+b)')
    })
  })

  describe('Given Apex code with various numeric types', () => {
    it('Then should generate mutation for Long return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Long test() {
            return x;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-x')
    })

    it('Then should generate mutation for Double return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Double test() {
            return 3.14;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-3.14')
    })

    it('Then should generate mutation for Decimal return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Decimal test() {
            return amount;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(1)
      expect(mutations[0].replacement).toBe('-amount')
    })
  })

  describe('Given Apex code with non-numeric return types', () => {
    it('Then should not generate mutation for List return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public List<String> test() {
            return items;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })

    it('Then should not generate mutation for Map return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Map<Id, Account> test() {
            return records;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })

    it('Then should not generate mutation for SObject return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Account test() {
            return acc;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })

    it('Then should not generate mutation for Date return type', async () => {
      // Arrange
      const code = `
        public class TestClass {
          public Date test() {
            return d;
          }
        }
      `

      // Act
      const mutations = await parseAndMutate(code, new Set([4]))

      // Assert
      expect(mutations.length).toBe(0)
    })
  })
})
